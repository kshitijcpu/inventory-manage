
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { User } from './types';
import { storage } from './services/storage';

// Pages
import Dashboard from './pages/Dashboard';
import Inventory from './pages/Inventory';
import Logs from './pages/Logs';
import Login from './pages/Login';
import Register from './pages/Register';

// Components
import Layout from './components/Layout';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const session = storage.getSession();
    if (session) {
      setUser(session);
    }
    setLoading(false);
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="w-12 h-12 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <Router>
      <Routes>
        {/* Auth Routes */}
        <Route path="/login" element={!user ? <Login onLogin={setUser} /> : <Navigate to="/" />} />
        <Route path="/register" element={!user ? <Register onRegister={setUser} /> : <Navigate to="/" />} />

        {/* Protected App Routes */}
        <Route 
          path="/" 
          element={
            user ? (
              <Layout user={user} setUser={setUser}>
                <Dashboard user={user} />
              </Layout>
            ) : (
              <Navigate to="/login" />
            )
          } 
        />
        <Route 
          path="/inventory" 
          element={
            user ? (
              <Layout user={user} setUser={setUser}>
                <Inventory user={user} />
              </Layout>
            ) : (
              <Navigate to="/login" />
            )
          } 
        />
        <Route 
          path="/logs" 
          element={
            user ? (
              <Layout user={user} setUser={setUser}>
                <Logs user={user} />
              </Layout>
            ) : (
              <Navigate to="/login" />
            )
          } 
        />
        <Route 
          path="/settings" 
          element={
            user ? (
              <Layout user={user} setUser={setUser}>
                <div className="p-12 text-center bg-white rounded-3xl border border-slate-100">
                  <h2 className="text-xl font-bold text-slate-800">User Settings</h2>
                  <p className="text-slate-400 mt-2">Manage your profile and application preferences here.</p>
                  <p className="mt-8 text-xs text-slate-300 font-bold uppercase tracking-widest">Modules under development</p>
                </div>
              </Layout>
            ) : (
              <Navigate to="/login" />
            )
          } 
        />
        
        {/* Catch all */}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </Router>
  );
};

export default App;
