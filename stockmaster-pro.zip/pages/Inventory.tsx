
import React, { useState, useMemo } from 'react';
import { User, InventoryItem, UserRole, StockLog } from '../types';
import { storage } from '../services/storage';
import { ICONS, CATEGORIES } from '../constants';

interface InventoryProps {
  user: User;
}

const Inventory: React.FC<InventoryProps> = ({ user }) => {
  const [items, setItems] = useState<InventoryItem[]>(() => storage.getInventory(user.id, user.role));
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    category: CATEGORIES[0],
    quantity: 0,
    unitPrice: 0,
    supplier: '',
    lowStockLevel: 5
  });

  const filteredItems = useMemo(() => {
    return items.filter(item => {
      const matchesSearch = item.name.toLowerCase().includes(search.toLowerCase()) || 
                            item.supplier.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = categoryFilter === '' || item.category === categoryFilter;
      return matchesSearch && matchesCategory;
    });
  }, [items, search, categoryFilter]);

  const handleOpenModal = (item?: InventoryItem) => {
    if (item) {
      setEditingItem(item);
      setFormData({
        name: item.name,
        category: item.category,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        supplier: item.supplier,
        lowStockLevel: item.lowStockLevel
      });
    } else {
      setEditingItem(null);
      setFormData({
        name: '',
        category: CATEGORIES[0],
        quantity: 0,
        unitPrice: 0,
        supplier: '',
        lowStockLevel: 5
      });
    }
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const now = new Date().toISOString();
    let updatedItems: InventoryItem[];

    if (editingItem) {
      updatedItems = items.map(i => {
        if (i.id === editingItem.id) {
          const newItem = { ...i, ...formData, updatedAt: now };
          
          // Log the change if quantity changed
          if (editingItem.quantity !== formData.quantity) {
            const log: StockLog = {
              id: Math.random().toString(36).substr(2, 9),
              itemId: i.id,
              userId: user.id,
              userName: user.name,
              changeAmount: formData.quantity - editingItem.quantity,
              previousQuantity: editingItem.quantity,
              newQuantity: formData.quantity,
              timestamp: now,
              type: formData.quantity > editingItem.quantity ? 'increase' : 'decrease'
            };
            storage.addLog(log);
          }
          return newItem;
        }
        return i;
      });
    } else {
      const newItem: InventoryItem = {
        id: Math.random().toString(36).substr(2, 9),
        ownerId: user.id,
        ...formData,
        createdAt: now,
        updatedAt: now
      };
      updatedItems = [newItem, ...items];
      
      const log: StockLog = {
        id: Math.random().toString(36).substr(2, 9),
        itemId: newItem.id,
        userId: user.id,
        userName: user.name,
        changeAmount: newItem.quantity,
        previousQuantity: 0,
        newQuantity: newItem.quantity,
        timestamp: now,
        type: 'creation'
      };
      storage.addLog(log);
    }

    setItems(updatedItems);
    storage.setInventory(updatedItems);
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      const updatedItems = items.filter(i => i.id !== id);
      setItems(updatedItems);
      storage.setInventory(updatedItems);
    }
  };

  const adjustStock = (item: InventoryItem, delta: number) => {
    const now = new Date().toISOString();
    const newQty = Math.max(0, item.quantity + delta);
    if (newQty === item.quantity) return;

    const updatedItems = items.map(i => {
      if (i.id === item.id) {
        return { ...i, quantity: newQty, updatedAt: now };
      }
      return i;
    });

    const log: StockLog = {
      id: Math.random().toString(36).substr(2, 9),
      itemId: item.id,
      userId: user.id,
      userName: user.name,
      changeAmount: delta,
      previousQuantity: item.quantity,
      newQuantity: newQty,
      timestamp: now,
      type: delta > 0 ? 'increase' : 'decrease'
    };

    setItems(updatedItems);
    storage.setInventory(updatedItems);
    storage.addLog(log);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Inventory Management</h1>
          <p className="text-slate-500">View and manage your product stock levels.</p>
        </div>
        <button 
          onClick={() => handleOpenModal()}
          className="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-semibold shadow-lg shadow-indigo-100 transition-all"
        >
          <ICONS.Add className="w-5 h-5" />
          <span>Add Product</span>
        </button>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <input 
            type="text" 
            placeholder="Search by product name or supplier..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 pl-11 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
          />
          <svg className="w-5 h-5 text-slate-400 absolute left-4 top-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>
        <select 
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="bg-white border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-slate-600"
        >
          <option value="">All Categories</option>
          {CATEGORIES.map(cat => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredItems.map(item => (
          <div key={item.id} className="bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow overflow-hidden group">
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 bg-slate-50 px-2 py-1 rounded-md mb-2 inline-block">
                    {item.category}
                  </span>
                  <h3 className="font-bold text-lg text-slate-900 leading-tight">{item.name}</h3>
                  <p className="text-xs text-slate-500 mt-1">Supplier: {item.supplier}</p>
                </div>
                <div className="flex items-center gap-1">
                  <button onClick={() => handleOpenModal(item)} className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                  </button>
                  <button onClick={() => handleDelete(item.id)} className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between py-4 border-y border-slate-50">
                <div>
                  <p className="text-xs text-slate-400 font-medium">UNIT PRICE</p>
                  <p className="text-lg font-bold text-slate-900">${item.unitPrice.toFixed(2)}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-slate-400 font-medium">STOCK VALUE</p>
                  <p className="text-lg font-bold text-slate-900">${(item.quantity * item.unitPrice).toFixed(2)}</p>
                </div>
              </div>

              <div className="mt-6 flex items-center justify-between">
                <div>
                   <p className="text-xs text-slate-400 font-medium">QUANTITY</p>
                   <p className={`text-xl font-extrabold ${item.quantity <= item.lowStockLevel ? 'text-rose-600' : 'text-emerald-600'}`}>
                    {item.quantity}
                   </p>
                </div>
                <div className="flex items-center bg-slate-50 rounded-xl p-1 shadow-inner">
                  <button 
                    onClick={() => adjustStock(item, -1)}
                    className="w-10 h-10 flex items-center justify-center bg-white text-slate-600 hover:text-indigo-600 rounded-lg shadow-sm border border-slate-100 transition-all active:scale-95"
                  >
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" /></svg>
                  </button>
                  <div className="w-8 text-center font-bold text-slate-400 text-xs">+/-</div>
                  <button 
                    onClick={() => adjustStock(item, 1)}
                    className="w-10 h-10 flex items-center justify-center bg-white text-slate-600 hover:text-indigo-600 rounded-lg shadow-sm border border-slate-100 transition-all active:scale-95"
                  >
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredItems.length === 0 && (
        <div className="text-center py-20">
          <div className="bg-slate-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-400">
             <ICONS.Inventory className="w-10 h-10" />
          </div>
          <h3 className="text-xl font-bold text-slate-800">No items found</h3>
          <p className="text-slate-500 mt-2">Try adjusting your filters or add a new product.</p>
        </div>
      )}

      {/* Product Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900">{editingItem ? 'Edit Product' : 'Add New Product'}</h2>
              <button onClick={() => setIsModalOpen(false)} className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <form onSubmit={handleSave} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Product Name</label>
                  <input 
                    type="text" 
                    required
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                    placeholder="e.g. Wireless Mouse"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Category</label>
                  <select 
                    value={formData.category}
                    onChange={e => setFormData({...formData, category: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                  >
                    {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Supplier</label>
                  <input 
                    type="text" 
                    required
                    value={formData.supplier}
                    onChange={e => setFormData({...formData, supplier: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                    placeholder="e.g. Logitech Inc."
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Quantity</label>
                  <input 
                    type="number" 
                    required
                    min="0"
                    value={formData.quantity}
                    onChange={e => setFormData({...formData, quantity: parseInt(e.target.value) || 0})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Unit Price ($)</label>
                  <input 
                    type="number" 
                    required
                    min="0"
                    step="0.01"
                    value={formData.unitPrice}
                    onChange={e => setFormData({...formData, unitPrice: parseFloat(e.target.value) || 0})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Low Stock Alert Level</label>
                  <input 
                    type="number" 
                    required
                    min="0"
                    value={formData.lowStockLevel}
                    onChange={e => setFormData({...formData, lowStockLevel: parseInt(e.target.value) || 0})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">Receive an alert when stock falls below this number.</p>
                </div>
              </div>
              <div className="pt-4 flex gap-3">
                <button 
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-xl transition-all"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="flex-1 py-3 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-lg shadow-indigo-100 transition-all"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Inventory;
