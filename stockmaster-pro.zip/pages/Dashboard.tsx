
import React, { useMemo } from 'react';
import { User, InventoryItem, UserRole } from '../types';
import { storage } from '../services/storage';
import { ICONS, CATEGORIES } from '../constants';
import StatCard from '../components/StatCard';
import { Link } from 'react-router-dom';

interface DashboardProps {
  user: User;
}

const Dashboard: React.FC<DashboardProps> = ({ user }) => {
  const items = useMemo(() => storage.getInventory(user.id, user.role), [user.id, user.role]);
  const logs = useMemo(() => storage.getLogs(user.id, user.role).slice(0, 5), [user.id, user.role]);

  const stats = useMemo(() => {
    return {
      total: items.length,
      value: items.reduce((acc, item) => acc + (item.quantity * item.unitPrice), 0),
      lowStock: items.filter(i => i.quantity > 0 && i.quantity <= i.lowStockLevel).length,
      outOfStock: items.filter(i => i.quantity === 0).length,
    };
  }, [items]);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header>
        <h1 className="text-2xl font-bold text-slate-900">Welcome back, {user.name}</h1>
        <p className="text-slate-500">Here's an overview of your inventory status today.</p>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        <StatCard label="Total Items" value={stats.total} icon={ICONS.Inventory} color="indigo" />
        <StatCard label="Stock Value" value={`$${stats.value.toLocaleString()}`} icon={ICONS.History} color="amber" />
        <StatCard label="Low Stock" value={stats.lowStock} icon={ICONS.Dashboard} color="orange" />
        <StatCard label="Out of Stock" value={stats.outOfStock} icon={ICONS.Add} color="rose" />
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Alerts & Critical Stock */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-50 flex items-center justify-between">
              <h2 className="font-bold text-slate-900">Low Stock Alerts</h2>
              <Link to="/inventory" className="text-sm font-semibold text-indigo-600 hover:text-indigo-700">View All</Link>
            </div>
            <div className="divide-y divide-slate-50">
              {items.filter(i => i.quantity <= i.lowStockLevel).length > 0 ? (
                items.filter(i => i.quantity <= i.lowStockLevel).slice(0, 5).map(item => (
                  <div key={item.id} className="p-4 flex items-center gap-4 hover:bg-slate-50 transition-colors">
                    <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center">
                      <ICONS.Inventory className="w-5 h-5 text-slate-400" />
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-slate-900">{item.name}</p>
                      <p className="text-xs text-slate-500">{item.category} • {item.supplier}</p>
                    </div>
                    <div className="text-right">
                      <p className={`font-bold ${item.quantity === 0 ? 'text-rose-600' : 'text-orange-600'}`}>
                        {item.quantity} {item.quantity === 1 ? 'unit' : 'units'} left
                      </p>
                      <p className="text-[10px] uppercase font-bold text-slate-400">Level: {item.lowStockLevel}</p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-12 text-center">
                  <p className="text-slate-400 italic">No low stock items. Everything looks good!</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-50">
              <h2 className="font-bold text-slate-900">Recent Logs</h2>
            </div>
            <div className="p-4 space-y-6">
              {logs.length > 0 ? (
                logs.map((log) => (
                  <div key={log.id} className="flex gap-4 relative">
                    <div className="flex flex-col items-center">
                      <div className={`w-3 h-3 rounded-full mt-1.5 ${
                        log.type === 'increase' ? 'bg-emerald-500' : 
                        log.type === 'decrease' ? 'bg-rose-500' : 
                        'bg-slate-400'
                      }`} />
                      <div className="w-0.5 flex-1 bg-slate-100 my-1" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-400 font-medium">{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                      <p className="text-sm text-slate-800">
                        <span className="font-bold">{log.userName}</span> 
                        {log.type === 'increase' ? ' added ' : log.type === 'decrease' ? ' removed ' : ' updated '}
                        <span className="font-medium">{Math.abs(log.changeAmount)} units</span>
                      </p>
                      <p className="text-[10px] text-slate-400 mt-0.5">Stock updated to {log.newQuantity}</p>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-center text-slate-400 py-4 italic">No recent activity.</p>
              )}
            </div>
            <div className="p-4 bg-slate-50 text-center">
              <Link to="/logs" className="text-xs font-bold text-slate-500 hover:text-indigo-600 uppercase tracking-widest">See Full History</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
