
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { storage } from '../services/storage';
import { User, UserRole } from '../types';

interface LoginProps {
  onLogin: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('admin@example.com');
  const [password, setPassword] = useState('password'); // Simulated
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Simulated Auth logic
    const users = storage.getUsers();
    const user = users.find(u => u.email === email);

    if (user && password === 'password') {
      storage.setSession(user);
      onLogin(user);
      navigate('/');
    } else {
      setError('Invalid email or password. Use password "password"');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <div className="w-full max-w-md animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="bg-white rounded-3xl shadow-xl shadow-slate-200 border border-slate-100 overflow-hidden">
          <div className="p-8 pb-0 flex flex-col items-center">
            <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center text-white text-3xl font-black mb-6 shadow-xl shadow-indigo-200">S</div>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight">StockMaster Pro</h1>
            <p className="text-slate-400 mt-2 font-medium">Log in to manage your inventory</p>
          </div>

          <form onSubmit={handleSubmit} className="p-8 space-y-5">
            {error && (
              <div className="p-4 bg-rose-50 text-rose-600 text-sm font-semibold rounded-xl border border-rose-100 animate-in shake duration-300">
                {error}
              </div>
            )}
            
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5 ml-1">Email Address</label>
              <input 
                type="email" 
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-3.5 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all font-medium"
                placeholder="you@company.com"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5 ml-1">Password</label>
              <input 
                type="password" 
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-3.5 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all font-medium"
                placeholder="••••••••"
              />
            </div>

            <div className="flex items-center justify-between py-2">
              <label className="flex items-center gap-2 cursor-pointer group">
                <input type="checkbox" className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300" />
                <span className="text-sm font-medium text-slate-500 group-hover:text-slate-700 transition-colors">Remember me</span>
              </label>
              <a href="#" className="text-sm font-bold text-indigo-600 hover:text-indigo-700 transition-colors">Forgot Password?</a>
            </div>

            <button 
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-black py-4 rounded-xl shadow-lg shadow-indigo-100 transform active:scale-[0.98] transition-all tracking-wide uppercase"
            >
              Sign In
            </button>
          </form>

          <div className="p-6 bg-slate-50 border-t border-slate-100 text-center">
            <p className="text-sm text-slate-500 font-medium">
              Don't have an account? <Link to="/register" className="text-indigo-600 font-bold hover:underline">Create Account</Link>
            </p>
          </div>
        </div>
        
        <div className="mt-8 text-center space-y-2">
          <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Demo Accounts</p>
          <div className="flex justify-center gap-4">
            <button onClick={() => setEmail('admin@example.com')} className="text-[10px] bg-white border border-slate-200 px-3 py-1 rounded-full text-slate-500 hover:border-indigo-500 hover:text-indigo-600 transition-all font-bold uppercase tracking-tighter">Admin</button>
            <button onClick={() => setEmail('staff@example.com')} className="text-[10px] bg-white border border-slate-200 px-3 py-1 rounded-full text-slate-500 hover:border-indigo-500 hover:text-indigo-600 transition-all font-bold uppercase tracking-tighter">Staff</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
