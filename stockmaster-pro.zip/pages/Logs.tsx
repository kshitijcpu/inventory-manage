
import React, { useMemo } from 'react';
import { User, StockLog } from '../types';
import { storage } from '../services/storage';

interface LogsProps {
  user: User;
}

const Logs: React.FC<LogsProps> = ({ user }) => {
  const logs = useMemo(() => storage.getLogs(user.id, user.role), [user.id, user.role]);

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header>
        <h1 className="text-2xl font-bold text-slate-900">Activity Logs</h1>
        <p className="text-slate-500">Audit trail of all inventory modifications.</p>
      </header>

      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50/50">
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Timestamp</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">User</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Action</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider text-right">Change</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider text-right">Balance</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {logs.length > 0 ? (
              logs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="px-6 py-4">
                    <p className="text-sm font-medium text-slate-900">{new Date(log.timestamp).toLocaleDateString()}</p>
                    <p className="text-[10px] text-slate-400 uppercase font-bold">{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center text-[10px] font-bold">
                        {log.userName.charAt(0)}
                      </div>
                      <span className="text-sm text-slate-700 font-medium">{log.userName}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full ${
                        log.type === 'increase' ? 'bg-emerald-500' : 
                        log.type === 'decrease' ? 'bg-rose-500' : 
                        log.type === 'creation' ? 'bg-indigo-500' : 'bg-slate-400'
                      }`} />
                      <span className="text-sm text-slate-600 capitalize">{log.type} Stock</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right font-mono font-bold">
                    <span className={log.changeAmount > 0 ? 'text-emerald-600' : log.changeAmount < 0 ? 'text-rose-600' : 'text-slate-400'}>
                      {log.changeAmount > 0 ? '+' : ''}{log.changeAmount}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <span className="text-sm font-bold text-slate-900">{log.newQuantity}</span>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={5} className="px-6 py-20 text-center text-slate-400 italic">No activity logs found.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Logs;
