
import { User, InventoryItem, StockLog, UserRole } from '../types';

const USERS_KEY = 'sm_users';
const ITEMS_KEY = 'sm_items';
const LOGS_KEY = 'sm_logs';
const SESSION_KEY = 'sm_session';

export const storage = {
  getUsers: (): User[] => {
    const data = localStorage.getItem(USERS_KEY);
    return data ? JSON.parse(data) : [
      { id: '1', name: 'Admin User', email: 'admin@example.com', role: UserRole.ADMIN, avatar: 'https://picsum.photos/200' },
      { id: '2', name: 'Staff Member', email: 'staff@example.com', role: UserRole.STAFF, avatar: 'https://picsum.photos/201' }
    ];
  },
  
  setUsers: (users: User[]) => {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  },

  getInventory: (userId: string, role: UserRole): InventoryItem[] => {
    const data = localStorage.getItem(ITEMS_KEY);
    const items: InventoryItem[] = data ? JSON.parse(data) : [];
    if (role === UserRole.ADMIN) return items;
    return items.filter(i => i.ownerId === userId);
  },

  setInventory: (items: InventoryItem[]) => {
    localStorage.setItem(ITEMS_KEY, JSON.stringify(items));
  },

  getLogs: (userId: string, role: UserRole): StockLog[] => {
    const data = localStorage.getItem(LOGS_KEY);
    const logs: StockLog[] = data ? JSON.parse(data) : [];
    if (role === UserRole.ADMIN) return logs;
    // For staff, they might only see logs for items they own or created
    return logs.filter(l => l.userId === userId);
  },

  addLog: (log: StockLog) => {
    const logs = storage.getLogs('all', UserRole.ADMIN);
    localStorage.setItem(LOGS_KEY, JSON.stringify([log, ...logs]));
  },

  getSession: (): User | null => {
    const data = localStorage.getItem(SESSION_KEY);
    return data ? JSON.parse(data) : null;
  },

  setSession: (user: User | null) => {
    if (user) {
      localStorage.setItem(SESSION_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(SESSION_KEY);
    }
  }
};
