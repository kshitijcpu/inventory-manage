
export enum UserRole {
  ADMIN = 'ADMIN',
  STAFF = 'STAFF'
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
}

export interface InventoryItem {
  id: string;
  ownerId: string;
  name: string;
  category: string;
  quantity: number;
  unitPrice: number;
  supplier: string;
  lowStockLevel: number;
  createdAt: string;
  updatedAt: string;
}

export interface StockLog {
  id: string;
  itemId: string;
  userId: string;
  userName: string;
  changeAmount: number;
  previousQuantity: number;
  newQuantity: number;
  timestamp: string;
  type: 'increase' | 'decrease' | 'set' | 'creation' | 'edit';
}

export interface DashboardStats {
  totalProducts: number;
  totalValue: number;
  lowStockCount: number;
  outOfStockCount: number;
}
